## News

In this version (1.1.1), I have fixed a bug related to an update of `bruceR` (thanks to Prof. Brian Ripley) and modified citation information.


## Test environments

* Windows 10 (local installation), R 4.1.2
* Mac OS 11.2 (user installation), R 4.0.4
* Ubuntu 16.04 (on travis-ci.com), R 4.0.2


## R CMD check results

There were no ERRORs, WARNINGs, or NOTEs.


## Downstream dependencies

No reverse dependency currently.
