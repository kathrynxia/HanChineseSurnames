**If you are viewing this file on CRAN, please check [latest news on GitHub](https://github.com/psychbruce/ChineseNames/blob/master/NEWS.md) where the formatting is also better.**

# ChineseNames 1.1.0 (June 2021)

-   Improved the speed of the function `compute_name_index()` for processing data with large sample size.
-   Added CSV data files.
-   Added LOGO.

# ChineseNames 1.0.0 (March 2021)

-   Initial release on CRAN.
